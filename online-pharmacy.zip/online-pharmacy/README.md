# Online Pharmacy - Full Stack Project (B.Tech Final Year)
Scaffold contains a Flask backend, basic frontend, DB schema, and a Java order processor stub.
Follow instructions in this repo to run locally.
